# Overview

SkillBridge is a full-stack educational platform that helps users discover and track learning resources organized by categories and skill levels. The application provides a curated experience for professional development with progress tracking, achievements, and a responsive modern interface.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

The client-side is built using **React 18** with TypeScript, implementing a modern component-based architecture:

- **Routing**: Uses Wouter for lightweight client-side routing with three main pages (Home, Resources, Progress)
- **State Management**: TanStack Query (React Query) for server state management and caching
- **UI Framework**: shadcn/ui components built on Radix UI primitives with Tailwind CSS for styling
- **Animations**: Framer Motion for smooth animations and transitions
- **Build Tool**: Vite for fast development and optimized builds

The application follows a modular structure with clear separation between pages, components, and utilities. The UI uses a design system with consistent theming through CSS custom properties.

## Backend Architecture

The server implements a **REST API** using Express.js with TypeScript:

- **Framework**: Express.js with middleware for JSON parsing, logging, and error handling
- **Database Layer**: Drizzle ORM with PostgreSQL for type-safe database operations
- **Storage Pattern**: Repository pattern with an in-memory storage implementation for development
- **Development Setup**: Vite integration for SSR in development mode with HMR support

The API provides endpoints for categories, resources, user progress, and achievements with proper error handling and request logging.

## Data Storage Solutions

- **Database**: PostgreSQL with Neon Database as the cloud provider
- **ORM**: Drizzle ORM for type-safe schema definitions and migrations
- **Schema Design**: 
  - Users table for authentication
  - Categories for resource organization
  - Resources with skill levels, duration, and content
  - User progress tracking with percentage completion
  - Achievements system for gamification

## Authentication and Authorization

Currently implements a basic user system with username/password authentication. The application uses session-based authentication with PostgreSQL session storage via connect-pg-simple middleware.

## Development and Deployment

- **Development**: Hot module reloading with Vite dev server
- **Build Process**: Vite builds the frontend, esbuild bundles the backend
- **Environment**: Configured for Replit deployment with specific plugins and error handling
- **TypeScript**: Full TypeScript support across frontend and backend with shared schema definitions

# External Dependencies

## Database
- **Neon Database**: PostgreSQL cloud database service
- **Drizzle ORM**: Type-safe database toolkit
- **connect-pg-simple**: PostgreSQL session store

## UI and Styling
- **shadcn/ui**: Component library built on Radix UI
- **Radix UI**: Unstyled, accessible UI primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Framer Motion**: Animation library

## Development Tools
- **Vite**: Build tool and dev server
- **TanStack Query**: Data fetching and caching
- **Wouter**: Lightweight router
- **TypeScript**: Type safety across the stack

## Fonts and Assets
- **Google Fonts**: Inter, Architects Daughter, DM Sans, Fira Code, Geist Mono
- **Unsplash**: Image hosting for resource thumbnails

## Deployment
- **Replit**: Primary deployment platform with specific configurations and plugins