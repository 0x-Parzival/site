import { 
  type User, 
  type InsertUser,
  type Category,
  type InsertCategory,
  type Resource,
  type InsertResource,
  type UserProgress,
  type InsertUserProgress,
  type Achievement,
  type InsertAchievement
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Categories
  getCategories(): Promise<Category[]>;
  getCategory(id: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;

  // Resources
  getResources(filters?: { categoryId?: string; skillLevel?: string; search?: string }): Promise<Resource[]>;
  getResource(id: string): Promise<Resource | undefined>;
  createResource(resource: InsertResource): Promise<Resource>;

  // User Progress
  getUserProgress(userId: string): Promise<UserProgress[]>;
  getUserResourceProgress(userId: string, resourceId: string): Promise<UserProgress | undefined>;
  updateUserProgress(userId: string, resourceId: string, progress: number): Promise<UserProgress>;

  // Achievements
  getUserAchievements(userId: string): Promise<Achievement[]>;
  createAchievement(achievement: InsertAchievement): Promise<Achievement>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private categories: Map<string, Category>;
  private resources: Map<string, Resource>;
  private userProgress: Map<string, UserProgress>;
  private achievements: Map<string, Achievement>;

  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.resources = new Map();
    this.userProgress = new Map();
    this.achievements = new Map();
    
    // Initialize with sample data
    this.initializeData();
  }

  private initializeData() {
    // Sample categories
    const categories: Category[] = [
      { id: "1", name: "Programming", slug: "programming", icon: "fas fa-code", color: "hsl(221 83% 53%)" },
      { id: "2", name: "Design", slug: "design", icon: "fas fa-palette", color: "hsl(281 83% 53%)" },
      { id: "3", name: "Marketing", slug: "marketing", icon: "fas fa-bullhorn", color: "hsl(21 83% 53%)" },
      { id: "4", name: "Business", slug: "business", icon: "fas fa-briefcase", color: "hsl(142 76% 36%)" },
      { id: "5", name: "Data Science", slug: "data-science", icon: "fas fa-chart-bar", color: "hsl(201 83% 53%)" },
      { id: "6", name: "Leadership", slug: "leadership", icon: "fas fa-users", color: "hsl(45 83% 53%)" },
    ];

    categories.forEach(category => this.categories.set(category.id, category));

    // Sample resources
    const resources: Resource[] = [
      {
        id: "1",
        title: "JavaScript Fundamentals",
        description: "Master the basics of JavaScript with interactive exercises and real-world projects.",
        categoryId: "1",
        skillLevel: "beginner",
        duration: 12,
        imageUrl: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=240",
        content: null,
        tags: ["javascript", "programming", "web-development"],
        createdAt: new Date(),
      },
      {
        id: "2",
        title: "UI/UX Design Principles",
        description: "Learn design thinking and create beautiful, user-centered interfaces.",
        categoryId: "2",
        skillLevel: "intermediate",
        duration: 18,
        imageUrl: "https://images.unsplash.com/photo-1561070791-2526d30994b5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=240",
        content: null,
        tags: ["ui", "ux", "design", "figma"],
        createdAt: new Date(),
      },
      {
        id: "3",
        title: "Digital Marketing Strategy",
        description: "Master advanced marketing techniques and data-driven campaign optimization.",
        categoryId: "3",
        skillLevel: "advanced",
        duration: 25,
        imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=240",
        content: null,
        tags: ["marketing", "digital", "strategy", "analytics"],
        createdAt: new Date(),
      },
      {
        id: "4",
        title: "Python for Data Analysis",
        description: "Learn to analyze and visualize data using Python, pandas, and matplotlib.",
        categoryId: "5",
        skillLevel: "intermediate",
        duration: 22,
        imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=240",
        content: null,
        tags: ["python", "data-analysis", "pandas", "visualization"],
        createdAt: new Date(),
      },
      {
        id: "5",
        title: "Business Strategy Fundamentals",
        description: "Understand core business concepts and strategic thinking frameworks.",
        categoryId: "4",
        skillLevel: "beginner",
        duration: 15,
        imageUrl: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=240",
        content: null,
        tags: ["business", "strategy", "management", "planning"],
        createdAt: new Date(),
      },
      {
        id: "6",
        title: "Executive Leadership",
        description: "Develop advanced leadership skills and team management techniques.",
        categoryId: "6",
        skillLevel: "advanced",
        duration: 30,
        imageUrl: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=240",
        content: null,
        tags: ["leadership", "management", "executive", "teams"],
        createdAt: new Date(),
      },
    ];

    resources.forEach(resource => this.resources.set(resource.id, resource));

    // Sample user progress
    const sampleUserId = "sample-user-123";
    const progressData: UserProgress[] = [
      { id: "p1", userId: sampleUserId, resourceId: "1", progress: 65, completedAt: null },
      { id: "p2", userId: sampleUserId, resourceId: "2", progress: 30, completedAt: null },
      { id: "p3", userId: sampleUserId, resourceId: "3", progress: 0, completedAt: null },
      { id: "p4", userId: sampleUserId, resourceId: "4", progress: 85, completedAt: null },
      { id: "p5", userId: sampleUserId, resourceId: "5", progress: 45, completedAt: null },
      { id: "p6", userId: sampleUserId, resourceId: "6", progress: 15, completedAt: null },
    ];

    progressData.forEach(progress => this.userProgress.set(progress.id, progress));

    // Sample achievements
    const achievementsData: Achievement[] = [
      {
        id: "a1",
        userId: sampleUserId,
        title: "JavaScript Master",
        description: "Completed JavaScript Fundamentals",
        icon: "fas fa-trophy",
        color: "hsl(142 76% 36%)",
        earnedAt: new Date(),
      },
      {
        id: "a2", 
        userId: sampleUserId,
        title: "Design Thinking",
        description: "Finished UI/UX principles module",
        icon: "fas fa-medal",
        color: "hsl(221 83% 53%)",
        earnedAt: new Date(),
      },
      {
        id: "a3",
        userId: sampleUserId,
        title: "Consistency Champion",
        description: "7-day learning streak",
        icon: "fas fa-star",
        color: "hsl(281 83% 53%)",
        earnedAt: new Date(),
      },
    ];

    achievementsData.forEach(achievement => this.achievements.set(achievement.id, achievement));
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategory(id: string): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = randomUUID();
    const category: Category = { ...insertCategory, id };
    this.categories.set(id, category);
    return category;
  }

  async getResources(filters?: { categoryId?: string; skillLevel?: string; search?: string }): Promise<Resource[]> {
    let resources = Array.from(this.resources.values());

    if (filters?.categoryId) {
      resources = resources.filter(r => r.categoryId === filters.categoryId);
    }

    if (filters?.skillLevel) {
      resources = resources.filter(r => r.skillLevel === filters.skillLevel);
    }

    if (filters?.search) {
      const searchLower = filters.search.toLowerCase();
      resources = resources.filter(r => 
        r.title.toLowerCase().includes(searchLower) ||
        r.description.toLowerCase().includes(searchLower) ||
        r.tags?.some(tag => tag.toLowerCase().includes(searchLower))
      );
    }

    return resources;
  }

  async getResource(id: string): Promise<Resource | undefined> {
    return this.resources.get(id);
  }

  async createResource(insertResource: InsertResource): Promise<Resource> {
    const id = randomUUID();
    const resource: Resource = { ...insertResource, id, createdAt: new Date() };
    this.resources.set(id, resource);
    return resource;
  }

  async getUserProgress(userId: string): Promise<UserProgress[]> {
    return Array.from(this.userProgress.values()).filter(p => p.userId === userId);
  }

  async getUserResourceProgress(userId: string, resourceId: string): Promise<UserProgress | undefined> {
    return Array.from(this.userProgress.values()).find(p => 
      p.userId === userId && p.resourceId === resourceId
    );
  }

  async updateUserProgress(userId: string, resourceId: string, progress: number): Promise<UserProgress> {
    const existing = await this.getUserResourceProgress(userId, resourceId);
    
    if (existing) {
      existing.progress = progress;
      if (progress >= 100 && !existing.completedAt) {
        existing.completedAt = new Date();
      }
      this.userProgress.set(existing.id, existing);
      return existing;
    } else {
      const id = randomUUID();
      const newProgress: UserProgress = {
        id,
        userId,
        resourceId,
        progress,
        completedAt: progress >= 100 ? new Date() : null,
      };
      this.userProgress.set(id, newProgress);
      return newProgress;
    }
  }

  async getUserAchievements(userId: string): Promise<Achievement[]> {
    return Array.from(this.achievements.values()).filter(a => a.userId === userId);
  }

  async createAchievement(insertAchievement: InsertAchievement): Promise<Achievement> {
    const id = randomUUID();
    const achievement: Achievement = { ...insertAchievement, id, earnedAt: new Date() };
    this.achievements.set(id, achievement);
    return achievement;
  }
}

export const storage = new MemStorage();
