import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Categories
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  // Resources
  app.get("/api/resources", async (req, res) => {
    try {
      const { categoryId, skillLevel, search } = req.query;
      const resources = await storage.getResources({
        categoryId: categoryId as string,
        skillLevel: skillLevel as string,
        search: search as string,
      });
      res.json(resources);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch resources" });
    }
  });

  app.get("/api/resources/:id", async (req, res) => {
    try {
      const resource = await storage.getResource(req.params.id);
      if (!resource) {
        return res.status(404).json({ message: "Resource not found" });
      }
      res.json(resource);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch resource" });
    }
  });

  // User Progress (using sample user for demo)
  app.get("/api/progress", async (req, res) => {
    try {
      const sampleUserId = "sample-user-123";
      const progress = await storage.getUserProgress(sampleUserId);
      res.json(progress);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch progress" });
    }
  });

  app.post("/api/progress", async (req, res) => {
    try {
      const schema = z.object({
        resourceId: z.string(),
        progress: z.number().min(0).max(100),
      });

      const { resourceId, progress } = schema.parse(req.body);
      const sampleUserId = "sample-user-123";
      
      const updatedProgress = await storage.updateUserProgress(sampleUserId, resourceId, progress);
      res.json(updatedProgress);
    } catch (error) {
      res.status(400).json({ message: "Invalid request body" });
    }
  });

  // Achievements
  app.get("/api/achievements", async (req, res) => {
    try {
      const sampleUserId = "sample-user-123";
      const achievements = await storage.getUserAchievements(sampleUserId);
      res.json(achievements);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch achievements" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
